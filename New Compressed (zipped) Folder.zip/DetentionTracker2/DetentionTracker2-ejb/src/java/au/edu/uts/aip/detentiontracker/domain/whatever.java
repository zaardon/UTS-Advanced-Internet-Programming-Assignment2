/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package au.edu.uts.aip.detentiontracker.domain;

/**
 *
 * @author james
 */
import javax.ejb.*;
import javax.persistence.*;

@Stateless
public class whatever {
     
    @PersistenceContext
    private EntityManager em;
}
